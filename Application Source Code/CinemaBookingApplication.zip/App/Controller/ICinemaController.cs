﻿namespace App.Controller;

public interface ICinemaController
{
    void StartCinemaApplication();
}