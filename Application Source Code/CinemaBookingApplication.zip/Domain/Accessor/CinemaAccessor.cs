﻿using Domain.Enums;
using Domain.Models;
using Domain.Utility;
using Microsoft.Extensions.Logging;

namespace Domain.Accessor;

public class CinemaAccessor(ILogger<CinemaAccessor> logger) : ICinemaAccessor
{
    public Cinema CreateCinema(string movie, int rows, int seatsPerRow)
    {
        return Cinema.Create(movie, rows, seatsPerRow);
    }

    public Cinema GetCinema()
    {
        try
        {
            return Cinema.GetCinema();
        }
        catch (Exception e)
        {
            Console.WriteLine("Exception occurred as no Cinema available!");
            var exceptionMessage = $"Exception occurred: {e.Message}";
            logger.LogCritical(exceptionMessage);
            throw;
        }
    }

    public Seat GetSeat(char rowLabel, int seatNumber)
    {
        try
        {
            var allSeats = Cinema.GetCinema().HallLayOut.RowLayOuts.SelectMany(row => row.Seats);
            return allSeats.Single(s => s.RowLabel == rowLabel && s.SeatNumber == seatNumber);
        }
        catch (Exception e)
        {
            var exceptionMessage = $"Exception occurred as no seat available for seat row: {rowLabel} seat number: {seatNumber}";
            Console.WriteLine(exceptionMessage);
            logger.LogCritical(exceptionMessage);
            logger.LogCritical(e.Message);
            throw;
        }
    }
    
    public void UpdateSeat(Seat seat, SeatStatus seatStatus, String bookingId)
    {
        seat.Update(seatStatus, bookingId);
    }

    public Booking? TryGetBooking(string bookingId)
    {
        return GetCinema().Bookings.SingleOrDefault(b => b.BookingId == bookingId);
    }

    public void AddBooking(Booking booking)
    {
        var cinema = GetCinema();

        var isBookingAlreadyExist = cinema.Bookings.Any(b => b.BookingId.Equals(booking.BookingId));

        if (isBookingAlreadyExist)
        {
            var exceptionMessage =
                string.Format($"{CinemaUtility.ExceptionMessage.BookingAlreadyExist}", booking.BookingId);
            logger.LogCritical(exceptionMessage);
            throw new Exception(exceptionMessage);
        }

        cinema.AddBooking(booking);
    }
}