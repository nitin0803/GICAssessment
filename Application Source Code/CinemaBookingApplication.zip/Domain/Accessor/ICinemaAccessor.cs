﻿using Domain.Enums;
using Domain.Models;

namespace Domain.Accessor;

public interface ICinemaAccessor
{
    Cinema CreateCinema(string movie, int rows, int seatsPerRow);
    Cinema GetCinema();

    Seat GetSeat(char rowLabel, int seatNumber);
    void UpdateSeat(Seat seat, SeatStatus seatStatus, String bookingId);

    Booking? TryGetBooking(string bookingId);
    void AddBooking(Booking booking);
}