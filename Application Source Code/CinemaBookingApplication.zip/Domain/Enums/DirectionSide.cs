﻿namespace Domain.Enums;

public enum DirectionSide
{
    Right,
    Left
}