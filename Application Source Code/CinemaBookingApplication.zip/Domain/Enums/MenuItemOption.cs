﻿namespace Domain.Enums;

public enum MenuItemOption
{
    None = 0,
    BookTickets = 1,
    CheckBookings= 2,
    Exit = 3,
}