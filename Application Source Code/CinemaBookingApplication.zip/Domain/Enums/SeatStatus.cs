﻿namespace Domain.Enums;

public enum SeatStatus
{
    Empty,
    Reserved,
    Confirmed
}