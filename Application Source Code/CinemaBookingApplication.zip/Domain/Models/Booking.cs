﻿namespace Domain.Models;

public record Booking(string BookingId, int NumberOfBookedSeats);