﻿using Domain.Enums;

namespace Domain.Models;

public class Seat(Char rowLabel, int seatNumber)
{
    public Char RowLabel { get; } = rowLabel;
    public int SeatNumber { get; } = seatNumber;
    public SeatStatus Status { get; private set; } = SeatStatus.Empty;
    public string? BookingId { get; private set; }

    internal void Update(SeatStatus seatStatus, string bookingId)
    {
        Status = seatStatus;
        BookingId = bookingId;
    }
}