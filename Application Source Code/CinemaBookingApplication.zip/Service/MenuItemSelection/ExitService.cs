﻿using Domain.CinemaConsole;
using Domain.Enums;
using Domain.Utility;
using Microsoft.Extensions.Logging;

namespace Service.MenuItemSelection;

public class ExitService(
    ICinemaConsole cinemaConsole,
    ILogger<ExitService> logger) : IMenuItemSelectionService
{
    public bool IsResponsible(MenuItemOption menuItemOption) => menuItemOption == MenuItemOption.Exit;

    public void Handle(MenuItemOption menuItemOption)
    {
        logger.LogInformation("User selected exit option");
        cinemaConsole.WriteLine(CinemaUtility.AppMessage.ThankYou);
        cinemaConsole.WriteEmptyLine();
    }
}