﻿namespace Service.Screen;

public interface IScreenService
{
    void Show(string currentBookingId);
}