﻿using System.Text;
using Domain.Accessor;
using Domain.CinemaConsole;
using Domain.Models;
using Domain.Enums;
using Microsoft.Extensions.Logging;

namespace Service.Screen;

public class ScreenService(
    ICinemaAccessor cinemaAccessor,
    ICinemaConsole cinemaConsole,
    ILogger<ScreenService> logger) : IScreenService
{
    public void Show(string currentBookingId)
    {
        logger.LogInformation($"Showing booking details for booking id: {currentBookingId}");
        var cinema = cinemaAccessor.GetCinema();
        var seatsPerRow = cinema.SeatsPerRow;

        cinemaConsole.WriteLine($"Booking id: {currentBookingId}");
        cinemaConsole.WriteLine("Selected seats: ");
        cinemaConsole.WriteEmptyLine();

        cinemaConsole.WriteLine("         S C R E E N                  ");
        var separator = new StringBuilder();
        for (var i = 0; i <= seatsPerRow * 3 + 2; i++)
        {
            separator.Append('-');
        }

        cinemaConsole.WriteLine(separator.ToString());
        var hallLayout = cinema.HallLayOut;
        var rowLayOuts = hallLayout.RowLayOuts;
        foreach (var rowLayOut in rowLayOuts)
        {
            var rowStringBuilder = new StringBuilder();
            rowStringBuilder.Append($"{rowLayOut.RowLabel} ");
            foreach (var seat in rowLayOut.Seats)
            {
                var seatSymbol = GetSeatSymbol(seat, currentBookingId);
                rowStringBuilder.Append(seatSymbol);
            }
            cinemaConsole.WriteLine(rowStringBuilder.ToString());
            cinemaConsole.WriteEmptyLine();
        }

        var seatNumber = new StringBuilder();
        var anyRowLayout = rowLayOuts.First();
        foreach (var seat in anyRowLayout.Seats)
        {
            seatNumber.Append(seat.SeatNumber + "  ");
        }

        cinemaConsole.WriteLine("   " + seatNumber);
        Console.WriteLine();
    }

    private static string GetSeatSymbol(Seat seat, string? currentBookingId)
    {
        return seat switch
        {
            { Status: SeatStatus.Empty } => " . ",
            { BookingId: var bookingId } when (bookingId == currentBookingId) => " o ",
            _ => " # "
        };
    }
}