﻿using Domain.Accessor;
using Domain.CinemaConsole;
using Domain.Enums;
using Domain.Models;
using Microsoft.Extensions.Logging;
using Moq;
using Service.MenuItemSelection;
using Service.Screen;
using Service.SeatSelection;
using Shouldly;

namespace UnitTests.Service.MenuItemSelection;

[TestClass]
public class BookTicketsServiceTest
{
    private readonly Mock<ICinemaConsole> cinemaConsoleMock = new();
    private readonly Mock<ICinemaAccessor> cinemaAccessorMock = new();
    private readonly Mock<ISeatSelectionService> seatSelectionServiceMock = new();
    private readonly Mock<IScreenService> screenServiceMock = new();
    private readonly Mock<ILogger<BookTicketsService>> loggerMock =new();
    private readonly BookTicketsService sut;

    public BookTicketsServiceTest()
    {
        sut = new BookTicketsService(
            cinemaConsoleMock.Object,
            cinemaAccessorMock.Object,
            seatSelectionServiceMock.Object,
            screenServiceMock.Object,
            loggerMock.Object);
    }

    [TestMethod]
    [DataRow(MenuItemOption.BookTickets, true)]
    [DataRow(MenuItemOption.CheckBookings, false)]
    [DataRow(MenuItemOption.Exit, false)]
    public void IsResponsible_GivenMenuItemOption_ReturnsCorrectResult(
        MenuItemOption menuItemOption,
        bool expectedResult)
    {
        // Arrange & Act
        var result = sut.IsResponsible(menuItemOption);

        // Assert
        result.ShouldBe(expectedResult);
    }

    [TestMethod]
    public void Handle_WhenNumberOfTicketsMoreThanAvailableSeats_ThenShowAlertAboutSeatAvailability()
    {
        // Arrange
        var cinema = Cinema.Create("TestMovieName", 2, 3);
        cinemaAccessorMock.Setup(m => m.GetCinema())
            .Returns(cinema);

        cinemaConsoleMock.Setup(m => m.ReadNumberOfTicketsToBook())
            .Returns("8");
        
        // Act
        sut.Handle(MenuItemOption.BookTickets);
        
        // Assert
        cinemaConsoleMock.Verify(m => m.WriteLine("Sorry, there are only 6 seats available."), Times.AtLeast(1));
    }

    [TestMethod]
    public void Handle_WhenNumberOfTicketsLessThaAvailableSeats_ThenReserveTicketsAndAskForAcceptOrNewSeatSelection()
    {
        // Arrange
        var cinema = Cinema.Create("TestMovieName", 2, 3);
        cinemaAccessorMock.Setup(m => m.GetCinema())
            .Returns(cinema);

        cinemaConsoleMock.Setup(m => m.ReadNumberOfTicketsToBook())
            .Returns("4");
        
        // Act
        sut.Handle(MenuItemOption.BookTickets);
        
        // Assert
        seatSelectionServiceMock.Verify(m => m.ReserveSeats(4, It.IsAny<string?>()));
        cinemaConsoleMock.Verify(m => m.WriteLine("Successfully reserved 4 TestMovieName tickets."), Times.Once);
        cinemaConsoleMock.Verify(m => m.WriteLine("Enter blank to accept seat selection, or enter new seating position:"), Times.Once);
    }

    [TestMethod]
    public void Handle_WhenUserAcceptReservedSeats_ThenConfirmTickets()
    {
        // Arrange
        var cinema = Cinema.Create("TestMovieName", 2, 3);
        cinemaAccessorMock.Setup(m => m.GetCinema())
            .Returns(cinema);

        cinemaConsoleMock.Setup(m => m.ReadNumberOfTicketsToBook())
            .Returns("4");

        cinemaConsoleMock.Setup(m => m.ReadNewSeatPosition())
            .Returns(string.Empty);
        
        seatSelectionServiceMock.Setup(m => m.ReserveSeats(4, It.IsAny<string?>()))
            .Returns("NewBookingId");
        
        // Act
        sut.Handle(MenuItemOption.BookTickets);
        
        // Assert
        seatSelectionServiceMock.Verify(m => m.ConfirmSeats("NewBookingId"), Times.Once());
    }
}