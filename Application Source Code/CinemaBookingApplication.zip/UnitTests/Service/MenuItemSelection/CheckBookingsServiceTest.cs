﻿using Domain.Accessor;
using Domain.CinemaConsole;
using Domain.Enums;
using Domain.Models;
using Microsoft.Extensions.Logging;
using Moq;
using Service.MenuItemSelection;
using Service.Screen;
using Shouldly;

namespace UnitTests.Service.MenuItemSelection;

[TestClass]
public class CheckBookingsServiceTest
{
    private readonly Mock<ICinemaAccessor> cinemaAccessorMock = new();
    private readonly Mock<IScreenService> screenServiceMock = new();
    private readonly Mock<ILogger<CheckBookingsService>> loggerMock = new();
    private readonly Mock<ICinemaConsole> cinemaConsoleMock = new();
    private readonly CheckBookingsService sut;

    public CheckBookingsServiceTest()
    {
        sut = new CheckBookingsService(
            cinemaAccessorMock.Object,
            screenServiceMock.Object,
            cinemaConsoleMock.Object,
            loggerMock.Object);
    }

    [TestMethod]
    [DataRow(MenuItemOption.BookTickets, false)]
    [DataRow(MenuItemOption.CheckBookings, true)]
    [DataRow(MenuItemOption.Exit, false)]
    public void IsResponsible_GivenMenuItemOption_ReturnsCorrectResult(
        MenuItemOption menuItemOption,
        bool expectedResult)
    {
        // Arrange & Act
        var result = sut.IsResponsible(menuItemOption);

        // Assert
        result.ShouldBe(expectedResult);
    }

    [TestMethod]
    public void Handle_GivenExistingBookingId_ThenShowBookingForThatBookingId()
    {
        // Arrange
        var cinema = Cinema.Create("TestMovieName", 2, 3);
        cinemaAccessorMock.Setup(m => m.GetCinema())
            .Returns(cinema);

        cinemaConsoleMock.SetupSequence(m => m.ReadBookingId())
            .Returns("GIC1234")
            .Returns(String.Empty);

        cinemaAccessorMock.Setup(m => m.TryGetBooking("GIC1234"))
            .Returns(new Booking("GIC1234", 4));

        // Act
        sut.Handle(MenuItemOption.CheckBookings);

        // Assert
        screenServiceMock.Verify(m => m.Show("GIC1234"), Times.Once);
        cinemaConsoleMock.Verify(m => m.WriteLine("Enter booking id, or enter blank to go back to main menu:"));
    }
}