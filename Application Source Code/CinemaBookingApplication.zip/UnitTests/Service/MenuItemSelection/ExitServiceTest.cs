﻿using Domain.CinemaConsole;
using Domain.Enums;
using Microsoft.Extensions.Logging;
using Moq;
using Service.MenuItemSelection;
using Shouldly;

namespace UnitTests.Service.MenuItemSelection;

[TestClass]
public class ExitServiceTest
{
    private readonly Mock<ICinemaConsole> cinemaConsoleMock = new();
    private readonly Mock<ILogger<ExitService>> loggerMock = new();
    private readonly ExitService sut;

    public ExitServiceTest()
    {
        sut = new ExitService(cinemaConsoleMock.Object, loggerMock.Object);
    }

    [TestMethod]
    [DataRow(MenuItemOption.BookTickets, false)]
    [DataRow(MenuItemOption.CheckBookings, false)]
    [DataRow(MenuItemOption.Exit, true)]
    public void IsResponsible_GivenMenuItemOption_ReturnsCorrectResult(
        MenuItemOption menuItemOption,
        bool expectedResult)
    {
        // Arrange & Act
        var result = sut.IsResponsible(menuItemOption);

        // Assert
        result.ShouldBe(expectedResult);
    }
    
    [TestMethod]
    public void Handle_ShowThankYouMessage()
    {
        // Arrange & Act
        sut.Handle(MenuItemOption.Exit);

        // Assert
        cinemaConsoleMock.Verify(m => m.WriteLine("Thank you for using GIC Cinemas system. Bye!"));
    }
}