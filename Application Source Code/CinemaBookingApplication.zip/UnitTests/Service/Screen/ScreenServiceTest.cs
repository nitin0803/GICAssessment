﻿using Domain.Accessor;
using Domain.CinemaConsole;
using Domain.Enums;
using Domain.Models;
using Microsoft.Extensions.Logging;
using Moq;
using Service.Screen;

namespace UnitTests.Service.Screen;

[TestClass]
public class ScreenServiceTest
{
    private readonly Mock<ICinemaAccessor> cinemaAccessorMock = new();
    private readonly Mock<ILogger<ScreenService>> loggerMock = new();
    private readonly Mock<ICinemaConsole> cinemaConsoleMock = new();
    private readonly ScreenService sut;

    public ScreenServiceTest()
    {
        sut = new ScreenService(
            cinemaAccessorMock.Object,
            cinemaConsoleMock.Object,
            loggerMock.Object);
    }
    
    [TestMethod]
    public void Show_GivenBookingId_ShowBookingDetailsWithSeatingPosition()
    {
        // Arrange
        var cinema = Cinema.Create("TestMovieName", 2, 2);
        cinemaAccessorMock.Setup(m => m.GetCinema())
            .Returns(cinema);
        var B_Row = cinema.HallLayOut.RowLayOuts[0];
        B_Row.Seats[1].Update(SeatStatus.Confirmed, "GIC0002");
        var A_Row = cinema.HallLayOut.RowLayOuts[1];
        A_Row.Seats[0].Update(SeatStatus.Confirmed, "GIC0001");
        A_Row.Seats[1].Update(SeatStatus.Confirmed, "GIC0001");
        
        // Act
        sut.Show("GIC0002");

        // Assert
        cinemaConsoleMock.Verify(m => m.WriteLine("Booking id: GIC0002"), Times.Once);
        cinemaConsoleMock.Verify(m => m.WriteLine("Selected seats: "), Times.Once);
        cinemaConsoleMock.Verify(m => m.WriteLine("         S C R E E N                  "), Times.Once);
        cinemaConsoleMock.Verify(m => m.WriteLine("---------"), Times.Once);
        cinemaConsoleMock.Verify(m => m.WriteLine("B  .  o "), Times.Once);
        cinemaConsoleMock.Verify(m => m.WriteLine("A  #  # "), Times.Once);
        cinemaConsoleMock.Verify(m => m.WriteLine("   1  2  "), Times.Once);
    }
}