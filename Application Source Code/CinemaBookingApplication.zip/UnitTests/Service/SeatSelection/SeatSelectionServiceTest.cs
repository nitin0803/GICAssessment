﻿using Domain.Accessor;
using Domain.Enums;
using Domain.Models;
using Microsoft.Extensions.Logging;
using Moq;
using Service.SeatSelection;
using Shouldly;

namespace UnitTests.Service.SeatSelection;

[TestClass]
public class SeatSelectionServiceTest
{
    private readonly Mock<ICinemaAccessor> cinemaAccessorMock = new();
    private readonly Mock<ILogger<SeatSelectionService>> loggerMock = new();
    private readonly SeatSelectionService sut;

    public SeatSelectionServiceTest()
    {
        sut = new SeatSelectionService(cinemaAccessorMock.Object, loggerMock.Object);
    }

    [TestMethod]
    public void ReserveSeats_GivenFirstBooking_CorrectlyReserveSeats()
    {
        // Arrange
        var cinema = Cinema.Create("TestMovieName", 2, 5);
        cinemaAccessorMock.Setup(m => m.GetCinema())
            .Returns(cinema);
        var A_RowSeats = cinema.HallLayOut.RowLayOuts[1].Seats;
        
        var A_Row_SeatNumber3 = A_RowSeats[2];
        cinemaAccessorMock.Setup(m => m.GetSeat('A', 3))
            .Returns(A_Row_SeatNumber3);
        
        var A_Row_SeatNumber4 = A_RowSeats[3];
        cinemaAccessorMock.Setup(m => m.GetSeat('A', 4))
            .Returns(A_Row_SeatNumber4);
        
        var A_Row_SeatNumber5 = A_RowSeats[4];
        cinemaAccessorMock.Setup(m => m.GetSeat('A', 5))
            .Returns(A_Row_SeatNumber5);

        // Act
        sut.ReserveSeats(1);

        // Assert
        cinemaAccessorMock.Verify(m => m.UpdateSeat(A_Row_SeatNumber3, SeatStatus.Reserved, "GIC0001"), Times.Once);
    }

    [TestMethod]
    public void ReserveSeats_GivenFirstBookingAndSpecifiedSeatPosition_CorrectlyReserveSeatFromThatPosition()
    {
        // Arrange
        var cinema = Cinema.Create("TestMovieName", 2, 5);
        cinemaAccessorMock.Setup(m => m.GetCinema())
            .Returns(cinema);
        
        var B_RowSeats = cinema.HallLayOut.RowLayOuts[0].Seats;
        
        var B_Row_SeatNumber4 = B_RowSeats[3];
        cinemaAccessorMock.Setup(m => m.GetSeat('A', 4))
            .Returns(B_Row_SeatNumber4);
        
        var B_Row_SeatNumber5 = B_RowSeats[4];
        cinemaAccessorMock.Setup(m => m.GetSeat('A', 5))
            .Returns(B_Row_SeatNumber5);

        // Act
        sut.ReserveSeats(1, "A04");

        // Assert
        cinemaAccessorMock.Verify(m => m.UpdateSeat(B_Row_SeatNumber4, SeatStatus.Reserved, "GIC0001"), Times.Once);

    }

    [TestMethod]
    public void ReserveSeats_GivenMiddleSeatConfirmedAndNewBookingRequested_CorrectlyReserveFirstEmptySeatRightFromMiddleSeat()
    {
        // Arrange
        var cinema = Cinema.Create("TestMovieName", 2, 5);
        cinemaAccessorMock.Setup(m => m.GetCinema())
            .Returns(cinema);
        var A_RowSeats = cinema.HallLayOut.RowLayOuts[1].Seats;
        
        var A_Row_SeatNumber3 = A_RowSeats[2];
        A_Row_SeatNumber3.Update(SeatStatus.Confirmed, "GIC0001");
        cinemaAccessorMock.Setup(m => m.GetSeat('A', 3))
            .Returns(A_Row_SeatNumber3);
        
        var A_Row_SeatNumber4 = A_RowSeats[3];
        cinemaAccessorMock.Setup(m => m.GetSeat('A', 4))
            .Returns(A_Row_SeatNumber4);
        
        var A_Row_SeatNumber5 = A_RowSeats[4];
        cinemaAccessorMock.Setup(m => m.GetSeat('A', 5))
            .Returns(A_Row_SeatNumber5);

        // Act
        sut.ReserveSeats(1);

        // Assert
        cinemaAccessorMock.Verify(m => m.UpdateSeat(A_Row_SeatNumber4, SeatStatus.Reserved, "GIC0001"), Times.Once);
    }

    [TestMethod]
    public void ReserveSeats_Given2SeatsConfirmedFromNewSeatPosition_CorrectlyReserveFirstEmptySeatTowardsRightFromNewSeatPosition()
    {
        // Arrange
        var cinema = Cinema.Create("TestMovieName", 2, 5);
        cinemaAccessorMock.Setup(m => m.GetCinema())
            .Returns(cinema);
        var A_RowSeats = cinema.HallLayOut.RowLayOuts[1].Seats;
        
        var A_Row_SeatNumber3 = A_RowSeats[2];
        A_Row_SeatNumber3.Update(SeatStatus.Confirmed, "GIC0001");
        cinemaAccessorMock.Setup(m => m.GetSeat('A', 3))
            .Returns(A_Row_SeatNumber3);
        
        var A_Row_SeatNumber4 = A_RowSeats[3];
        A_Row_SeatNumber4.Update(SeatStatus.Confirmed, "GIC0001");
        cinemaAccessorMock.Setup(m => m.GetSeat('A', 4))
            .Returns(A_Row_SeatNumber4);
        
        var A_Row_SeatNumber5 = A_RowSeats[4];
        cinemaAccessorMock.Setup(m => m.GetSeat('A', 5))
            .Returns(A_Row_SeatNumber5);

        // Act
        sut.ReserveSeats(1, "A03");

        // Assert
        cinemaAccessorMock.Verify(m => m.UpdateSeat(A_Row_SeatNumber5, SeatStatus.Reserved, "GIC0001"), Times.Once);
    }

    [TestMethod]
    public void ConfirmSeats_GivenBookingId_UpdateReservedSeatsToConfirmedAndNewBooking()
    {
        // Arrange
        var cinema = Cinema.Create("TestMovieName", 2, 5);
        cinemaAccessorMock.Setup(m => m.GetCinema())
            .Returns(cinema);
        
        var A_RowSeats = cinema.HallLayOut.RowLayOuts[1].Seats;
        
        var A_Row_SeatNumber2 = A_RowSeats[1];
        A_Row_SeatNumber2.Update(SeatStatus.Reserved, "GIC0001");
        cinemaAccessorMock.Setup(m => m.GetSeat('A', 2))
            .Returns(A_Row_SeatNumber2);
        
        var A_Row_SeatNumber3 = A_RowSeats[2];
        A_Row_SeatNumber3.Update(SeatStatus.Reserved, "GIC0001");
        cinemaAccessorMock.Setup(m => m.GetSeat('A', 3))
            .Returns(A_Row_SeatNumber3);
        
        var A_Row_SeatNumber4 = A_RowSeats[3];
        A_Row_SeatNumber4.Update(SeatStatus.Reserved, "GIC0001");
        cinemaAccessorMock.Setup(m => m.GetSeat('A', 4))
            .Returns(A_Row_SeatNumber4);
        
        // Act
        sut.ConfirmSeats("GIC0001");
        
        // Assert
        cinemaAccessorMock.Verify(m => m.UpdateSeat(A_Row_SeatNumber2, SeatStatus.Confirmed, "GIC0001"), Times.Once);
        cinemaAccessorMock.Verify(m => m.UpdateSeat(A_Row_SeatNumber3, SeatStatus.Confirmed, "GIC0001"), Times.Once);
        cinemaAccessorMock.Verify(m => m.UpdateSeat(A_Row_SeatNumber4, SeatStatus.Confirmed, "GIC0001"), Times.Once);

        cinemaAccessorMock.Verify(m => m.AddBooking(It.IsAny<Booking>()), Times.Once);
    }

    [TestMethod]
    public void FreeSeats_GivenBookingId_UpdateReservedSeatsToEmptySeats()
    {
        // Arrange
        var cinema = Cinema.Create("TestMovieName", 2, 5);
        cinemaAccessorMock.Setup(m => m.GetCinema())
            .Returns(cinema);
        
        var A_RowSeats = cinema.HallLayOut.RowLayOuts[1].Seats;
        
        var A_Row_SeatNumber2 = A_RowSeats[1];
        A_Row_SeatNumber2.Update(SeatStatus.Reserved, "GIC0001");
        
        var A_Row_SeatNumber3 = A_RowSeats[2];
        A_Row_SeatNumber3.Update(SeatStatus.Reserved, "GIC0001");
        
        var A_Row_SeatNumber4 = A_RowSeats[3];
        A_Row_SeatNumber4.Update(SeatStatus.Reserved, "GIC0001");
        
        // Act
        sut.FreeSeats("GIC0001");
        
        // Assert
        cinemaAccessorMock.Verify(m => m.UpdateSeat(A_Row_SeatNumber2, SeatStatus.Empty, "GIC0001"), Times.Once);
        cinemaAccessorMock.Verify(m => m.UpdateSeat(A_Row_SeatNumber3, SeatStatus.Empty, "GIC0001"), Times.Once);
        cinemaAccessorMock.Verify(m => m.UpdateSeat(A_Row_SeatNumber4, SeatStatus.Empty, "GIC0001"), Times.Once);
    }
}